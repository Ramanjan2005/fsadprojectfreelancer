
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Link } from 'react-router-dom';

const categories = [
  {
    id: 1,
    name: "Web Development",
    icon: "💻",
    slug: "web-development"
  },
  {
    id: 2,
    name: "Design & Creative",
    icon: "🎨",
    slug: "design-creative"
  },
  {
    id: 3,
    name: "Writing & Translation",
    icon: "✍️",
    slug: "writing-translation"
  },
  {
    id: 4,
    name: "Digital Marketing",
    icon: "📱",
    slug: "digital-marketing"
  },
  {
    id: 5,
    name: "Video & Animation",
    icon: "🎬",
    slug: "video-animation"
  },
  {
    id: 6,
    name: "Data Science & AI",
    icon: "🤖",
    slug: "data-science-ai"
  }
];

const FeaturedCategories = () => {
  return (
    <section className="py-12 bg-gray-50">
      <div className="container">
        <div className="text-center mb-10">
          <h2 className="text-3xl md:text-4xl font-heading font-medium text-primary mb-4">Popular Skills</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Explore our most in-demand skills and find the perfect freelancer for your project
          </p>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 md:gap-6">
          {categories.map(category => (
            <Link to={`/category/${category.slug}`} key={category.id}>
              <Card className="hover:shadow-md transition-shadow h-full bg-white hover:border-secondary">
                <CardContent className="p-6 flex flex-col items-center justify-center text-center">
                  <div className="text-4xl mb-4">
                    {category.icon}
                  </div>
                  <h3 className="font-medium text-primary">{category.name}</h3>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturedCategories;
