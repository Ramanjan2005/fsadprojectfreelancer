
import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Search } from 'lucide-react';

const Hero = () => {
  return (
    <section className="relative bg-primary py-16 md:py-24">
      {/* Lamp decoration */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 md:w-48">
        <div className="w-1 h-16 md:h-24 bg-secondary mx-auto"></div>
        <div className="w-20 md:w-32 h-10 md:h-16 bg-secondary rounded-t-full mx-auto"></div>
        <div className="w-16 md:w-24 h-8 md:h-12 bg-white rounded-full mx-auto -mt-4 md:-mt-6 opacity-70"></div>
        <div className="w-24 md:w-32 h-16 md:h-24 bg-white/10 rounded-full mx-auto -mt-8 blur-md"></div>
      </div>
      
      <div className="container relative z-10 text-center pt-16 md:pt-12">
        <h1 className="text-4xl md:text-6xl lg:text-7xl font-heading font-medium text-white mb-6 leading-tight">
          Hire Expert Freelancers
        </h1>
        <p className="text-lg md:text-xl text-gray-200 max-w-2xl mx-auto mb-8">
          Connect with talented freelancers for your projects. Get quality work done quickly at competitive rates.
        </p>
        
        <div className="max-w-xl mx-auto">
          <div className="flex gap-2 md:gap-4">
            <Input 
              type="text" 
              placeholder="Search for skills or services" 
              className="bg-white/90 backdrop-blur-sm text-gray-900 ring-secondary/50 focus:ring-secondary"
            />
            <Button 
              size="lg"
              className="bg-secondary hover:bg-secondary/90 text-secondary-foreground"
            >
              <Search className="h-4 w-4 mr-2" />
              Search
            </Button>
          </div>
          <div className="mt-4 text-gray-200 text-sm">
            <span className="mr-2">Popular:</span>
            <Button variant="link" className="text-white hover:text-secondary p-0 mr-2">Web Development</Button>
            <Button variant="link" className="text-white hover:text-secondary p-0 mr-2">Design</Button>
            <Button variant="link" className="text-white hover:text-secondary p-0">Writing</Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
