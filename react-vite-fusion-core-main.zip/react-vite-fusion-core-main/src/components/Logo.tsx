
import React from 'react';

interface LogoProps {
  className?: string;
  showText?: boolean;
}

const Logo: React.FC<LogoProps> = ({ className = "", showText = true }) => {
  return (
    <div className={`flex items-center gap-2 ${className}`}>
      <img 
        src="/lovable-uploads/eced7281-556b-4d84-aafb-a636b7592e26.png"
        alt="Marketplace Logo" 
        className="h-10 w-auto"
      />
      {showText && (
        <span className="text-primary font-heading italic text-2xl">marketplace</span>
      )}
    </div>
  );
};

export default Logo;
