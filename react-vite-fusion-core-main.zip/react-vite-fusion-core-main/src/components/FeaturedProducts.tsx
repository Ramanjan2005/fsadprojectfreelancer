
import React from 'react';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Link, useNavigate } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';

const freelancers = [
  {
    id: 1,
    name: "V. Ramanjan",
    title: "Full Stack Developer",
    rate: 45,
    image: "/lovable-uploads/a5f6a68e-7ff3-4c0c-a093-ddfda74f5c23.png",
    slug: "v-ramanjan",
    rating: 4.9,
    skills: ["React", "Node.js", "MongoDB", "TypeScript"]
  },
  {
    id: 2,
    name: "Hari",
    title: "UI/UX Designer",
    rate: 55,
    image: "/lovable-uploads/067dc771-ee4b-4337-a28b-50bf27ff8b68.png",
    slug: "hari",
    rating: 5.0,
    skills: ["Figma", "Adobe XD", "User Research", "Prototyping"]
  },
  {
    id: 3,
    name: "Adithya",
    title: "Digital Marketing Expert",
    rate: 40,
    image: "/lovable-uploads/b9e30453-1c79-4e91-a7c4-860efb1c4a0b.png",
    slug: "adithya",
    rating: 4.7,
    skills: ["SEO", "Content Marketing", "Social Media", "Analytics"]
  },
  {
    id: 4,
    name: "Priya Sharma",
    title: "Content Writer",
    rate: 35,
    image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=300&q=80",
    slug: "priya-sharma",
    rating: 4.8,
    skills: ["Copywriting", "Editing", "Blogging", "Technical Writing"]
  }
];

const FeaturedProducts = () => {
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleContact = (freelancer: typeof freelancers[0]) => {
    toast({
      title: "Contact Request Sent",
      description: `A message has been sent to ${freelancer.name}. They will contact you soon!`,
    });
  };

  const handleHire = (freelancer: typeof freelancers[0]) => {
    navigate(`/freelancer/${freelancer.slug}`);
  };
  
  return (
    <section className="py-12">
      <div className="container">
        <div className="flex justify-between items-center mb-10">
          <h2 className="text-3xl font-heading font-medium text-primary">Top Freelancers</h2>
          <Link to="/freelancers">
            <Button variant="outline">View All</Button>
          </Link>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {freelancers.map(freelancer => (
            <Card key={freelancer.id} className="overflow-hidden hover:shadow-lg transition-shadow">
              <Link to={`/freelancer/${freelancer.slug}`}>
                <div className="relative aspect-square overflow-hidden">
                  <img 
                    src={freelancer.image} 
                    alt={freelancer.name}
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-2 right-2 bg-white/90 text-primary font-semibold text-sm py-1 px-2 rounded-full">
                    ⭐ {freelancer.rating}
                  </div>
                </div>
                <CardContent className="p-4">
                  <h3 className="font-medium text-lg mb-1">{freelancer.name}</h3>
                  <div className="text-gray-500 mb-2">{freelancer.title}</div>
                  <div className="text-primary font-semibold mb-2">${freelancer.rate}/hr</div>
                  <div className="flex flex-wrap gap-1 mt-2">
                    {freelancer.skills.slice(0, 2).map((skill, index) => (
                      <span key={index} className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded-full">
                        {skill}
                      </span>
                    ))}
                    {freelancer.skills.length > 2 && (
                      <span className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded-full">
                        +{freelancer.skills.length - 2} more
                      </span>
                    )}
                  </div>
                </CardContent>
              </Link>
              <CardFooter className="p-4 pt-0 flex gap-2">
                <Button 
                  className="w-1/2 bg-secondary hover:bg-secondary/90 text-secondary-foreground"
                  onClick={() => handleContact(freelancer)}
                >
                  Contact
                </Button>
                <Button 
                  className="w-1/2 bg-primary hover:bg-primary/90 text-primary-foreground"
                  onClick={() => handleHire(freelancer)}
                >
                  Hire
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturedProducts;
