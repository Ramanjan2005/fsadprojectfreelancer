
import React from 'react';
import { useParams } from 'react-router-dom';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { Button } from '@/components/ui/button';

const CategoryPage = () => {
  const { slug } = useParams<{ slug: string }>();
  
  // This would normally come from an API
  const freelancers = [
    { 
      id: 1, 
      name: "Alex Johnson", 
      title: "Senior Graphic Designer",
      rating: 4.9,
      hourlyRate: 45,
      image: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&h=400&auto=format&fit=crop&q=80"
    },
    { 
      id: 2, 
      name: "Maya Patel", 
      title: "UI/UX Designer",
      rating: 4.8,
      hourlyRate: 55,
      image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&h=400&auto=format&fit=crop&q=80"
    },
    { 
      id: 3, 
      name: "Thomas Wright", 
      title: "Branding Specialist",
      rating: 4.7,
      hourlyRate: 50,
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&auto=format&fit=crop&q=80"
    },
    { 
      id: 4, 
      name: "Sarah Chen", 
      title: "Motion Graphics Designer",
      rating: 4.9,
      hourlyRate: 60,
      image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&h=400&auto=format&fit=crop&q=80"
    },
  ];

  const formatSlug = (slug: string) => {
    return slug.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <div className="bg-gray-50 py-16">
        <div className="container">
          <h1 className="text-4xl font-bold text-primary mb-2">
            {formatSlug(slug || 'Category')}
          </h1>
          <p className="text-lg text-gray-600 mb-8">
            Find talented {formatSlug(slug || 'Category')} experts for your project
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {freelancers.map((freelancer) => (
              <div key={freelancer.id} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
                <div className="w-full aspect-square overflow-hidden">
                  <img 
                    src={freelancer.image} 
                    alt={freelancer.name} 
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-4">
                  <h3 className="font-bold text-lg">{freelancer.name}</h3>
                  <p className="text-sm text-gray-600 mb-2">{freelancer.title}</p>
                  
                  <div className="flex items-center mb-3">
                    <div className="text-yellow-500 flex items-center">
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
                        <path fillRule="evenodd" d="M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.007 5.404.433c1.164.093 1.636 1.545.749 2.305l-4.117 3.527 1.257 5.273c.271 1.136-.964 2.033-1.96 1.425L12 18.354 7.373 21.18c-.996.608-2.231-.29-1.96-1.425l1.257-5.273-4.117-3.527c-.887-.76-.415-2.212.749-2.305l5.404-.433 2.082-5.006z" clipRule="evenodd" />
                      </svg>
                      <span className="ml-1 font-medium">{freelancer.rating}</span>
                    </div>
                    <span className="mx-2 text-gray-300">|</span>
                    <span className="font-medium">${freelancer.hourlyRate}/hr</span>
                  </div>
                  
                  <Button className="w-full bg-secondary hover:bg-secondary/90 text-secondary-foreground">
                    View Profile
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default CategoryPage;
