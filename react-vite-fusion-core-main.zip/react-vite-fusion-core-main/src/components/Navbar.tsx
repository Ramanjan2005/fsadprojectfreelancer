
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { Menu, X } from 'lucide-react';
import Logo from './Logo';

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="bg-white shadow-sm">
      <div className="container py-4 flex items-center justify-between">
        <Link to="/" className="flex items-center">
          <Logo />
        </Link>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center space-x-6">
          <Link to="/" className="text-gray-700 hover:text-primary font-medium transition-colors">
            Home
          </Link>
          <Link to="/projects" className="text-gray-700 hover:text-primary font-medium transition-colors">
            Find Projects
          </Link>
          <Link to="/freelancers" className="text-gray-700 hover:text-primary font-medium transition-colors">
            Find Freelancers
          </Link>
          <Link to="/how-it-works" className="text-gray-700 hover:text-primary font-medium transition-colors">
            How It Works
          </Link>
        </div>

        <div className="hidden md:flex items-center space-x-4">
          <Link to="/login">
            <Button variant="outline" className="font-medium">
              Sign In
            </Button>
          </Link>
          <Link to="/post-project">
            <Button className="bg-secondary hover:bg-secondary/90 text-secondary-foreground font-medium">
              Post a Project
            </Button>
          </Link>
        </div>

        {/* Mobile menu button */}
        <div className="md:hidden">
          <Button variant="ghost" size="icon" onClick={() => setIsOpen(!isOpen)} aria-label="Menu">
            {isOpen ? <X /> : <Menu />}
          </Button>
        </div>
      </div>

      {/* Mobile Navigation */}
      {isOpen && (
        <div className="md:hidden bg-white p-4 shadow-inner">
          <div className="flex flex-col space-y-4">
            <Link 
              to="/" 
              className="text-gray-700 hover:text-primary font-medium py-2 transition-colors"
              onClick={() => setIsOpen(false)}
            >
              Home
            </Link>
            <Link 
              to="/projects" 
              className="text-gray-700 hover:text-primary font-medium py-2 transition-colors"
              onClick={() => setIsOpen(false)}
            >
              Find Projects
            </Link>
            <Link 
              to="/freelancers" 
              className="text-gray-700 hover:text-primary font-medium py-2 transition-colors"
              onClick={() => setIsOpen(false)}
            >
              Find Freelancers
            </Link>
            <Link 
              to="/how-it-works" 
              className="text-gray-700 hover:text-primary font-medium py-2 transition-colors"
              onClick={() => setIsOpen(false)}
            >
              How It Works
            </Link>
            <div className="pt-2 flex flex-col space-y-3">
              <Link to="/login" className="w-full" onClick={() => setIsOpen(false)}>
                <Button variant="outline" className="w-full justify-center font-medium">
                  Sign In
                </Button>
              </Link>
              <Link to="/post-project" className="w-full" onClick={() => setIsOpen(false)}>
                <Button className="w-full justify-center bg-secondary hover:bg-secondary/90 text-secondary-foreground font-medium">
                  Post a Project
                </Button>
              </Link>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
