
import React from 'react';
import { useParams } from 'react-router-dom';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const FreelancerProfile = () => {
  const { slug } = useParams<{ slug: string }>();
  
  // This would normally come from an API
  const freelancer = {
    id: 1,
    name: "Alex Johnson",
    title: "Senior Graphic Designer",
    rating: 4.9,
    hourlyRate: 45,
    image: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&h=400&auto=format&fit=crop&q=80",
    location: "New York, USA",
    bio: "Professional graphic designer with over 8 years of experience specializing in branding, print design, and digital media. I've worked with clients from various industries including tech, fashion, and entertainment.",
    skills: ["Photoshop", "Illustrator", "InDesign", "After Effects", "Branding", "Logo Design", "UI/UX"],
    education: [
      {
        degree: "BFA in Graphic Design",
        school: "Parsons School of Design",
        year: "2015"
      }
    ],
    experience: [
      {
        title: "Senior Graphic Designer",
        company: "CreativeWorks Agency",
        duration: "2018 - Present",
        description: "Lead designer for major brand campaigns and digital products."
      },
      {
        title: "Graphic Designer",
        company: "DigitalFirst Media",
        duration: "2015 - 2018",
        description: "Created visual assets for web and print media."
      }
    ],
    projects: [
      {
        title: "Brand Identity for Tech Startup",
        description: "Complete rebrand including logo, style guide, and marketing materials.",
        image: "https://images.unsplash.com/photo-1626785774573-4b799315345d?w=600&auto=format&fit=crop&q=80"
      },
      {
        title: "E-commerce Website Redesign",
        description: "UI/UX redesign resulting in 40% increase in conversion rate.",
        image: "https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?w=600&auto=format&fit=crop&q=80"
      },
      {
        title: "Marketing Campaign for Fashion Brand",
        description: "Series of digital and print ads for seasonal collection launch.",
        image: "https://images.unsplash.com/photo-1560850038-f95de6e715b3?w=600&auto=format&fit=crop&q=80"
      }
    ]
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <div className="bg-gray-50 py-12">
        <div className="container">
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            {/* Profile Header */}
            <div className="bg-primary/10 p-6 sm:p-8">
              <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6">
                <div className="w-32 h-32 overflow-hidden rounded-full border-4 border-white shadow-lg">
                  <img 
                    src={freelancer.image} 
                    alt={freelancer.name} 
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex-1 text-center sm:text-left">
                  <h1 className="text-2xl sm:text-3xl font-bold text-primary">{freelancer.name}</h1>
                  <p className="text-lg text-gray-700 mb-2">{freelancer.title}</p>
                  <p className="text-gray-600 mb-3">{freelancer.location}</p>
                  <div className="flex flex-wrap gap-2 justify-center sm:justify-start mb-4">
                    <div className="bg-primary/5 text-primary px-3 py-1 rounded-full text-sm font-medium flex items-center">
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-4 h-4 mr-1">
                        <path fillRule="evenodd" d="M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.007 5.404.433c1.164.093 1.636 1.545.749 2.305l-4.117 3.527 1.257 5.273c.271 1.136-.964 2.033-1.96 1.425L12 18.354 7.373 21.18c-.996.608-2.231-.29-1.96-1.425l1.257-5.273-4.117-3.527c-.887-.76-.415-2.212.749-2.305l5.404-.433 2.082-5.006z" clipRule="evenodd" />
                      </svg>
                      {freelancer.rating} (154 reviews)
                    </div>
                    <div className="bg-secondary/10 text-secondary px-3 py-1 rounded-full text-sm font-medium">
                      ${freelancer.hourlyRate}/hr
                    </div>
                  </div>
                  <div className="flex flex-col sm:flex-row gap-3 justify-center sm:justify-start">
                    <Button className="bg-secondary hover:bg-secondary/90 text-secondary-foreground">
                      Contact Me
                    </Button>
                    <Button variant="outline">
                      Save to Favorites
                    </Button>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Profile Content */}
            <div className="p-6 sm:p-8">
              <Tabs defaultValue="about">
                <TabsList className="mb-6 grid w-full grid-cols-3 bg-gray-100">
                  <TabsTrigger value="about">About</TabsTrigger>
                  <TabsTrigger value="portfolio">Portfolio</TabsTrigger>
                  <TabsTrigger value="reviews">Reviews</TabsTrigger>
                </TabsList>
                
                <TabsContent value="about" className="space-y-6">
                  <div>
                    <h2 className="text-xl font-semibold mb-3">About Me</h2>
                    <p className="text-gray-700">{freelancer.bio}</p>
                  </div>
                  
                  <div>
                    <h2 className="text-xl font-semibold mb-3">Skills</h2>
                    <div className="flex flex-wrap gap-2">
                      {freelancer.skills.map((skill, index) => (
                        <span 
                          key={index} 
                          className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm"
                        >
                          {skill}
                        </span>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <h2 className="text-xl font-semibold mb-3">Work Experience</h2>
                    <div className="space-y-4">
                      {freelancer.experience.map((exp, index) => (
                        <div key={index} className="border-l-2 border-gray-200 pl-4">
                          <h3 className="font-medium text-lg">{exp.title}</h3>
                          <p className="text-primary font-medium">{exp.company}</p>
                          <p className="text-sm text-gray-500">{exp.duration}</p>
                          <p className="text-gray-600 mt-1">{exp.description}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <h2 className="text-xl font-semibold mb-3">Education</h2>
                    <div className="space-y-4">
                      {freelancer.education.map((edu, index) => (
                        <div key={index} className="border-l-2 border-gray-200 pl-4">
                          <h3 className="font-medium text-lg">{edu.degree}</h3>
                          <p className="text-primary font-medium">{edu.school}</p>
                          <p className="text-sm text-gray-500">{edu.year}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="portfolio" className="space-y-6">
                  <div>
                    <h2 className="text-xl font-semibold mb-4">Portfolio Projects</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {freelancer.projects.map((project, index) => (
                        <div key={index} className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow">
                          <div className="aspect-video overflow-hidden">
                            <img 
                              src={project.image} 
                              alt={project.title} 
                              className="w-full h-full object-cover"
                            />
                          </div>
                          <div className="p-4">
                            <h3 className="font-medium text-lg">{project.title}</h3>
                            <p className="text-gray-600 text-sm">{project.description}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="reviews" className="space-y-6">
                  <div>
                    <h2 className="text-xl font-semibold mb-4">Client Reviews</h2>
                    <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 text-center mb-6">
                      <div className="text-yellow-500 text-4xl font-bold">{freelancer.rating}</div>
                      <div className="text-yellow-500 flex justify-center my-1">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <svg key={star} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
                            <path fillRule="evenodd" d="M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.007 5.404.433c1.164.093 1.636 1.545.749 2.305l-4.117 3.527 1.257 5.273c.271 1.136-.964 2.033-1.96 1.425L12 18.354 7.373 21.18c-.996.608-2.231-.29-1.96-1.425l1.257-5.273-4.117-3.527c-.887-.76-.415-2.212.749-2.305l5.404-.433 2.082-5.006z" clipRule="evenodd" />
                          </svg>
                        ))}
                      </div>
                      <div className="text-gray-600">Based on 154 reviews</div>
                    </div>
                    
                    <p className="text-center text-gray-500">
                      Reviews will be displayed here once available.
                    </p>
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default FreelancerProfile;
