
import React from 'react';
import { Link } from 'react-router-dom';
import Navbar from '@/components/Navbar';
import Hero from '@/components/Hero';
import FeaturedCategories from '@/components/FeaturedCategories';
import FeaturedProducts from '@/components/FeaturedProducts';
import Footer from '@/components/Footer';
import { Button } from '@/components/ui/button';

const Index = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow">
        <Hero />
        <FeaturedCategories />
        <FeaturedProducts />
        <section className="py-12 bg-gray-50">
          <div className="container">
            <div className="max-w-3xl mx-auto text-center">
              <h2 className="text-3xl font-heading font-medium text-primary mb-4">Join Our Freelancing Community Today</h2>
              <p className="text-gray-600 mb-8">
                Whether you're looking to hire talented professionals or showcase your skills to potential clients, our platform connects you with opportunities worldwide.
              </p>
              <div className="flex flex-col sm:flex-row justify-center gap-4">
                <Link to="/signup">
                  <Button className="bg-secondary text-secondary-foreground px-6 py-3 rounded-md font-medium hover:bg-secondary/90 transition-colors">
                    I Want to Hire
                  </Button>
                </Link>
                <Link to="/signup">
                  <Button className="bg-primary text-primary-foreground px-6 py-3 rounded-md font-medium hover:bg-primary/90 transition-colors">
                    I Want to Work
                  </Button>
                </Link>
              </div>
              <div className="mt-8">
                <Link to="/how-it-works">
                  <Button variant="link" className="text-primary underline">
                    Learn how it works →
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>
        <section className="py-12 bg-primary/5">
          <div className="container">
            <div className="max-w-4xl mx-auto">
              <div className="flex flex-col md:flex-row items-center justify-between gap-8">
                <div className="md:w-1/2">
                  <h2 className="text-3xl font-heading font-medium text-primary mb-4">Why Choose Marketplace?</h2>
                  <ul className="space-y-4">
                    <li className="flex items-start gap-3">
                      <div className="bg-secondary rounded-full p-1 mt-1">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-secondary-foreground" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                        </svg>
                      </div>
                      <div>
                        <h3 className="font-medium text-gray-900">Vetted Professionals</h3>
                        <p className="text-gray-600 text-sm">Our freelancers go through a thorough verification process</p>
                      </div>
                    </li>
                    <li className="flex items-start gap-3">
                      <div className="bg-secondary rounded-full p-1 mt-1">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-secondary-foreground" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                        </svg>
                      </div>
                      <div>
                        <h3 className="font-medium text-gray-900">Secure Payments</h3>
                        <p className="text-gray-600 text-sm">Funds are only released when you're completely satisfied</p>
                      </div>
                    </li>
                    <li className="flex items-start gap-3">
                      <div className="bg-secondary rounded-full p-1 mt-1">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-secondary-foreground" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                        </svg>
                      </div>
                      <div>
                        <h3 className="font-medium text-gray-900">24/7 Support</h3>
                        <p className="text-gray-600 text-sm">Our team is always available to help with any questions</p>
                      </div>
                    </li>
                  </ul>
                </div>
                <div className="md:w-1/2">
                  <img 
                    src="/lovable-uploads/56e730d5-c870-484d-84b3-72a63cfe1117.png" 
                    alt="Freelancer Marketplace Description" 
                    className="rounded-lg shadow-lg"
                  />
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default Index;
